Breakout
========

A simple Brick Breaker game written in Java. Run it as a NetBeans project, or use the following shell commands in the source directory: javac *.java && java Game
