
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

public class Brick extends GameObject {

    
    private final int interval = 50;
    final static int HEIGHT = 12;
    final static int WIDTH = 45;
    private final String brickBreakSoundFile = "sound\\EXPLOSAO.wav";
    
    
    Timer animationTimer;
    
    private int ANIMATION_STEPS = 4;
     
    public int imageOn = 0;
    
    public boolean visible = true;
    
    public int hits = 0;
    
    
    public Brick(int x, int y) {
        super(x, y, 0, 0, WIDTH, HEIGHT);
    }
    
    public Brick(int x, int y, Color c) {
        super(x, y, 0, 0, WIDTH, HEIGHT);
        color = c;
        
        if(c == Color.white){
            hits = -1;
            ANIMATION_STEPS = 5;
        }
    }

    @Override
    public void accelerate() {
        
    }

    @Override
    
    public void draw(Graphics g) {
       //Don't draw an invisible brick
        if (visible == false) {
            return;
        }
        g.setColor(color);
        String str;
        if (color.equals(Color.BLUE)) {
            str = "img\\brick_blue.gif";
        } else if (color.equals(Color.RED)) {
            str = "img\\brick_red.gif";
        } else if (color.equals(Color.white)) {
            str = "img\\brick_white.png";
        } else {
            str = "img\\brick.gif";
        }
        Picture.draw(g, str, x, y, WIDTH, HEIGHT, imageOn);

    }

    @Override
   
    public Intersection intersects(GameObject other) {
        Intersection i = super.intersects(other);
        if (i != Intersection.NONE) {
        }
        return i;
    }
   
    void disappear(final PongCourt pc) {
        if(hits <0){
            hits++;
            imageOn++;
            return;
        }
        //Explode the brick!
        animationTimer = new Timer(interval, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                animationTick(pc);
            }
        });
        animationTimer.start();
    }
    
   
    public void animationTick(PongCourt pc) {
        if (imageOn < ANIMATION_STEPS - 1) {
            imageOn++;
        } else {
            visible = false;
            animationTimer.stop();
            pc.repaint();
        }
    }
    
    void playSound() {
       // Sound brickBreakSound = new Sound(brickBreakSoundFile);
      //  brickBreakSound.playSoundOnce();
    }
}
