

public enum Intersection {
    NONE, UP, LEFT, DOWN, RIGHT
}
