 
import java.awt.Color;

public class BronzeBallPowerUp extends PowerUp {
  
   public BronzeBallPowerUp(int x, int y) {
      super(x, y, 0, 0);
     // color = Color.ORANGE;
   }
}
