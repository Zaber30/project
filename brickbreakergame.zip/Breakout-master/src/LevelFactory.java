import java.awt.Color;

public class LevelFactory {
    private Color color = Color.black;
    private final static int BRICK_SEPARATION_X = 8;
    private final static int BRICK_SEPARATION_Y = 8;
    private final static int NUM_LEVELS = 4;
    private int levelOn;

    public LevelFactory(int initialLevel) {
        if (initialLevel >= 1 && initialLevel <= NUM_LEVELS) {
            this.levelOn = initialLevel;
        } else {
            this.levelOn = 1; // Default to level 1 if invalid level is provided
        }
    }

    public Brick[][] getLevelArray() {
        Brick[][] bricks = new Brick[12][14];

        switch (levelOn) {
            case 1:
            default:
                for (int i = 0; i < bricks.length; i++) {
                    for (int j = 0; j < bricks[i].length; j++) {
                        if (i >= 6 && i <= 7 && j >= 6 && j <= 7) {
                            bricks[i][j] = rb(i, j);
                        }
                    }
                }
                break;

            case 2:
                for (int i = 0; i < bricks.length; i++) {
                    for (int j = 0; j < bricks[i].length; j++) {
                        if (j > 2 && j < 5) {
                            color = Color.BLUE;
                            bricks[i][j] = bb(i, j);
                        }
                        if(j>=5&&j<7){
                            bricks[i][j]=rb(i,j);
                        }
                        if(j==7){
                            bricks[i][j]= wb(i,j);
                        }
                    }
                }
                break;

            case 3:
                bricks = new Brick[][] {
                        {null, null, null, null, null, null, null, null, null, null, null, null},
                        {null, null, bb(2, 1), bb(3, 1), bb(4, 1), bb(5, 1), bb(6, 1), bb(7, 1), bb(8, 1), bb(9, 1), bb(10, 1), null},
                        {null, null, bb(2, 2), bb(3, 2), bb(4, 2), bb(5, 2), bb(6, 2), bb(7, 2), bb(8, 2), bb(9, 2), bb(10, 2), null},
                        {null, null, bb(2, 3), bb(3, 3), bb(4, 3), bb(5, 3), bb(6, 3), bb(7, 3), bb(8, 3), bb(9, 3), bb(10, 3), null},
                        {null, null, bb(2, 4), bb(3, 4), bb(4, 4), bb(5, 4), bb(6, 4), bb(7, 4), bb(8, 4), bb(9, 4), bb(10, 4), null},
                        {null, null, bb(2, 5), bb(3, 5), bb(4, 5), bb(5, 5), bb(6, 5), bb(7, 5), bb(8, 5), bb(9, 5), bb(10, 5), null},
                        {null, null, bb(2, 6), bb(3, 6), bb(4, 6), bb(5, 6), bb(6, 6), bb(7, 6), bb(8, 6), bb(9, 6), bb(10, 6), null},
                        {null, null, rb(2, 7), rb(3, 7), rb(4, 7), rb(5, 7), rb(6, 7), rb(7, 7), rb(8, 7), rb(9, 7), rb(10, 7), null},
                        {null, null, rb(2, 8), rb(3, 8), rb(4, 8), rb(5, 8), rb(6, 8), rb(7, 8), rb(8, 8), rb(9, 8), rb(10, 8), null},
                        {null, null, rb(2, 9), rb(3, 9), rb(4, 9), rb(5, 9), rb(6, 9), rb(7, 9), rb(8, 9), rb(9, 9), rb(10, 9), null},
                        {null, null, bb(2, 10), bb(3, 10), bb(4, 10), bb(5, 10), bb(6, 10), bb(7, 10), bb(8, 10), bb(9, 10), bb(10, 10), null},
                        {null, null, null, null, null, null, null, null, null, null, null, null}
                };
                break;
                
            
        }

        return bricks;
    }

    private Brick def_b(int i, int j) {
        return new Brick(BRICK_SEPARATION_X + ((BRICK_SEPARATION_X + Brick.WIDTH) * i),
                BRICK_SEPARATION_Y + ((BRICK_SEPARATION_Y + Brick.HEIGHT) * j));
    }

    private Brick rb(int i, int j) {
        return new Brick(BRICK_SEPARATION_X + ((BRICK_SEPARATION_X + Brick.WIDTH) * i),
                BRICK_SEPARATION_Y + ((BRICK_SEPARATION_Y + Brick.HEIGHT) * j), Color.red);
    }

    private Brick bb(int i, int j) {
        return new Brick(BRICK_SEPARATION_X + ((BRICK_SEPARATION_X + Brick.WIDTH) * i),
                BRICK_SEPARATION_Y + ((BRICK_SEPARATION_Y + Brick.HEIGHT) * j), Color.blue);
    }
     private Brick wb(int i, int j) {
      return new Brick(BRICK_SEPARATION_X + ((BRICK_SEPARATION_X + Brick.WIDTH) * i),
         BRICK_SEPARATION_Y + ((BRICK_SEPARATION_Y + Brick.HEIGHT) * j), Color.white);
      
   }

    public int getNumLevels() {
        return NUM_LEVELS;
    }

    public int levelOn() {
        return levelOn;
    }

    public boolean hasMoreLevels() {
        return levelOn < NUM_LEVELS;
    }

    public void nextLevel() {
        if (levelOn < NUM_LEVELS) {
            levelOn++;
        }
    }
}
