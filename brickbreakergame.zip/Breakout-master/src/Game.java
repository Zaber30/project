import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Game implements Runnable {
    public void run() {
        MainMenuFrame mainMenu = new MainMenuFrame();
        mainMenu.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Game());
    }
}

// Main menu frame with Play, Help, and Exit options
class MainMenuFrame extends JFrame {
    public MainMenuFrame() {
        setTitle("Main Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        getContentPane().setBackground(new Color(240, 240, 240));

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1, 10, 10));
        add(panel, BorderLayout.CENTER);

        Font buttonFont = new Font("Arial", Font.BOLD, 24);

        // Play button
        JButton playButton = new JButton("Play");
        playButton.setFont(buttonFont);
        playButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                LevelSelectionFrame levelFrame = new LevelSelectionFrame();
                levelFrame.setVisible(true);
                dispose();
            }
        });
        panel.add(playButton);

        // Help button
        JButton helpButton = new JButton("Help");
        helpButton.setFont(buttonFont);
        helpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(MainMenuFrame.this,
                        "Welcome to Brick Breaker!\n\n"
                                + "Controls:\n"
                                + "- Use the mouse to move the paddle.\n"
                                + "- Break all the bricks to win the level.\n"
                                + "- Avoid letting the ball fall below the paddle.\n\n"
                                + "Good luck!",
                        "Help", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        panel.add(helpButton);

        // Exit button
        JButton exitButton = new JButton("Exit");
        exitButton.setFont(buttonFont);
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        panel.add(exitButton);
    }
}

// Level selection frame
class LevelSelectionFrame extends JFrame {
    public LevelSelectionFrame() {
        setTitle("Select Level");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        getContentPane().setBackground(new Color(240, 240, 240));

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1, 10, 10));
        add(panel, BorderLayout.CENTER);

        Font buttonFont = new Font("Arial", Font.BOLD, 24);

        // Level 1 button
        JButton level1Button = new JButton("Play Level 1");
        level1Button.setFont(buttonFont);
        level1Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GameFrame gameFrame = new GameFrame(1);
                gameFrame.setVisible(true);
                dispose();
            }
        });
        panel.add(level1Button);

        // Level 2 button
        JButton level2Button = new JButton("Play Level 2");
        level2Button.setFont(buttonFont);
        level2Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GameFrame gameFrame = new GameFrame(2);
                gameFrame.setVisible(true);
                dispose();
            }
        });
        panel.add(level2Button);

        // Level 3 button
        JButton level3Button = new JButton("Play Level 3");
        level3Button.setFont(buttonFont);
        level3Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GameFrame gameFrame = new GameFrame(3);
                gameFrame.setVisible(true);
                dispose();
            }
        });
        panel.add(level3Button);
    }
}

// Game frame for playing the selected level
class GameFrame extends JFrame {
    public GameFrame(int level) {
        setTitle("Brick Breaker - Level " + level);
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        final PongCourt court = new PongCourt(level); // Pass the level to PongCourt
        add(court, BorderLayout.CENTER);

        JPanel panel = new JPanel();
        add(panel, BorderLayout.SOUTH);

        // Restart button
        JButton reset = new JButton("Restart");
        reset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                court.reset();
            }
        });
        panel.add(reset);

        // Score display
        JTextPane score = new JTextPane();
        score.setText("Score: 0");
        score.setEditable(false);
        court.setScoreJTP(score);
        panel.add(score);

        // Bricks left display
        JTextPane bricksLeft = new JTextPane();
        bricksLeft.setText("Bricks left: Initializing...");
        bricksLeft.setEditable(false);
        court.setBricksLeftJTP(bricksLeft);
        panel.add(bricksLeft);

        // Level display
        JTextPane levelPane = new JTextPane();
        levelPane.setText("Level: " + level);
        levelPane.setEditable(false);
        court.setLevelJTP(levelPane);
        panel.add(levelPane);

        // Lives display
        JTextPane lives = new JTextPane();
        lives.setText("Lives: Initializing...");
        lives.setEditable(false);
        court.setLivesJTP(lives);
        panel.add(lives);

        pack();
        setLocationRelativeTo(null);
        court.reset();
    }
}
