
import java.awt.Color;


public class MultiBallPowerUp extends PowerUp{
   public MultiBallPowerUp(int x, int y) {
      super(x, y, 0, 6);
      color = Color.CYAN;
   }
}
