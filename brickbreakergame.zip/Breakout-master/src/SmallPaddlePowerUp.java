
import java.awt.Color;

public class SmallPaddlePowerUp extends PowerUp{
   
   
   public SmallPaddlePowerUp(int x, int y) {
      super(x, y, 0, 0);
      color = Color.RED;
   }
   
   
   
}
