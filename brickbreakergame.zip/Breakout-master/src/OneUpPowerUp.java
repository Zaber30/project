
import java.awt.Color;

public class OneUpPowerUp extends PowerUp {
   
  
   public OneUpPowerUp(int x, int y) {
      super(x, y, 0, 0);
     color = Color.GREEN;
   }
}
